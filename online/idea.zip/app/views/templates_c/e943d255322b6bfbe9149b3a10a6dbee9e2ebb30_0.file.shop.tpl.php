<?php
/* Smarty version 4.2.1, created on 2023-03-26 12:32:11
  from '/home/hambrenc/public_html/app/views/templates/products/shop.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_64203b4b726772_30732015',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e943d255322b6bfbe9149b3a10a6dbee9e2ebb30' => 
    array (
      0 => '/home/hambrenc/public_html/app/views/templates/products/shop.tpl',
      1 => 1679820752,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64203b4b726772_30732015 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_194823638864203b4b722b92_04874599', "body");
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "index.tpl");
}
/* {block "body"} */
class Block_194823638864203b4b722b92_04874599 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_194823638864203b4b722b92_04874599',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div class="axil-breadcrumb-area">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-8">
                    <div class="inner">
                        <ul class="axil-breadcrumb">
                            <li class="axil-breadcrumb-item"><a href="index.html">Home</a></li>
                            <li class="separator"></li>
                            <li class="axil-breadcrumb-item active" aria-current="page">Shop</li>
                        </ul>
                        <h1 class="title">Explore All Products</h1>
                    </div>
                </div>
                <div class="col-lg-6 col-md-4">
                    <div class="inner">
                        <div class="bradcrumb-thumb">
                            <img src="/assets/images/product/product-45.png" alt="Image">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<div class="axil-shop-area axil-section-gap bg-color-white">
    <div class="container">
        <div class="row row--15">
            <div class="col-lg-12">
                <div class="axil-shop-top">
                    <div class="row">
                        <div class="col-lg-9">
                            <div class="category-select">

                                <!-- Start Single Select  -->
                                <select class="single-select">
                                    <option>Categories</option>
                                    <option>Fashion</option>
                                    <option>Electronics</option>
                                    <option>Furniture</option>
                                    <option>Beauty</option>
                                </select>
                                <!-- End Single Select  -->

                                <!-- Start Single Select  -->
                                <select class="single-select">
                                    <option>Color</option>
                                    <option>Red</option>
                                    <option>Blue</option>
                                    <option>Green</option>
                                    <option>Pink</option>
                                </select>
                                <!-- End Single Select  -->

                                <!-- Start Single Select  -->
                                <select class="single-select">
                                    <option>Price Range</option>
                                    <option>0 - 100</option>
                                    <option>100 - 500</option>
                                    <option>500 - 1000</option>
                                    <option>1000 - 1500</option>
                                </select>
                                <!-- End Single Select  -->

                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="category-select mt_md--10 mt_sm--10 justify-content-lg-end">
                                <!-- Start Single Select  -->
                                <select class="single-select">
                                    <option>Sort by Latest</option>
                                    <option>Sort by Name</option>
                                    <option>Sort by Price</option>
                                    <option>Sort by Viewed</option>
                                </select>
                                <!-- End Single Select  -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['recently_added_products']->value, 'product');
$_smarty_tpl->tpl_vars['product']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['product']->value) {
$_smarty_tpl->tpl_vars['product']->do_else = false;
?>
                <div class="col-xl-2 col-lg-3 col-sm-6">
                    <div class="axil-product product-style-one has-color-pick mt--40">
                        <div class="thumbnail">
                            <a href="/products/<?php echo $_smarty_tpl->tpl_vars['product']->value['url'];?>
">
                                <img src="/media/products_thumbnails/<?php echo $_smarty_tpl->tpl_vars['product']->value['feature_photo'];?>
" alt="Product Images">
                            </a>
                            <div class="label-block label-right">
                                <div class="product-badget">20% OFF</div>
                            </div>
                            <div class="product-hover-action">
                                <ul class="cart-action">
                                    <li class="wishlist"><a href="#"><i class="far fa-heart"></i></a></li>
                                    <li class="select-option"><a href="#">Add to Cart</a></li>
                                    <li class="quickview"><a href="/shop" data-bs-toggle="modal" data-bs-target="#quick-view-modal"><i class="far fa-eye"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="product-content">
                            <div class="inner">
                                <h5 class="title text-truncate"><a href="/product/<?php echo $_smarty_tpl->tpl_vars['product']->value['url'];?>
"><?php echo $_smarty_tpl->tpl_vars['product']->value['name'];?>
</a></h5>
                                <div class="product-price-variant">
                                    <span class="price current-price"><?php echo $_smarty_tpl->tpl_vars['product']->value['price_2'];?>
</span>
                                    <span class="price old-price"><?php echo $_smarty_tpl->tpl_vars['product']->value['price_1'];?>
</span>
                                </div>
                                <div class="color-variant-wrapper">
                                    <ul class="color-variant">
                                        <li class="color-extra-01 active"><span><span class="color"></span></span>
                                        </li>
                                        <li class="color-extra-02"><span><span class="color"></span></span>
                                        </li>
                                        <li class="color-extra-03"><span><span class="color"></span></span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

        </div>
    </div>
</div>
<?php
}
}
/* {/block "body"} */
}
