<?php
/* Smarty version 4.2.1, created on 2023-03-26 10:53:01
  from '/home/hambrenc/public_html/app/views/templates/products/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_6420240ddac593_46584963',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7b6b988c07ec485fe3a9e8d397b6d6b8af050adb' => 
    array (
      0 => '/home/hambrenc/public_html/app/views/templates/products/index.tpl',
      1 => 1679820752,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6420240ddac593_46584963 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_4307327406420240dda8d37_73990805', "body");
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "index.tpl");
}
/* {block "body"} */
class Block_4307327406420240dda8d37_73990805 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_4307327406420240dda8d37_73990805',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="axil-shop-area axil-section-gap bg-color-white">
    <div class="container">
        <div class="row row--15">
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['products']->value, 'product');
$_smarty_tpl->tpl_vars['product']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['product']->value) {
$_smarty_tpl->tpl_vars['product']->do_else = false;
?>
                <div class="col-xl-3 col-lg-4 col-sm-6">
                    <div class="axil-product product-style-one has-color-pick mt--40">
                        <div class="thumbnail">
                            <a href="/products/<?php echo $_smarty_tpl->tpl_vars['product']->value['url'];?>
">
                                <img src="/media/products_thumbnails/<?php echo $_smarty_tpl->tpl_vars['product']->value['feature_photo'];?>
" alt="Product Images">
                            </a>
                            <div class="label-block label-right">
                                <div class="product-badget">20% OFF</div>
                            </div>
                            <div class="product-hover-action">
                                <ul class="cart-action">
                                    <li class="wishlist"><a href="#"><i class="far fa-heart"></i></a></li>
                                    <li class="select-option"><a href="#">Add to Cart</a></li>
                                    <li class="quickview"><a href="/shop" data-bs-toggle="modal" data-bs-target="#quick-view-modal"><i class="far fa-eye"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="product-content">
                            <div class="inner">
                                <h5 class="title"><a href="/product/<?php echo $_smarty_tpl->tpl_vars['product']->value['url'];?>
"><?php echo $_smarty_tpl->tpl_vars['product']->value['name'];?>
</a></h5>
                                <div class="product-price-variant">
                                    <span class="price current-price"><?php echo $_smarty_tpl->tpl_vars['product']->value['price_2'];?>
</span>
                                    <span class="price old-price"><?php echo $_smarty_tpl->tpl_vars['product']->value['price_1'];?>
</span>
                                </div>
                                <div class="color-variant-wrapper">
                                    <ul class="color-variant">
                                        <li class="color-extra-01 active"><span><span class="color"></span></span>
                                        </li>
                                        <li class="color-extra-02"><span><span class="color"></span></span>
                                        </li>
                                        <li class="color-extra-03"><span><span class="color"></span></span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

        </div>
    </div>
</div>
<?php
}
}
/* {/block "body"} */
}
