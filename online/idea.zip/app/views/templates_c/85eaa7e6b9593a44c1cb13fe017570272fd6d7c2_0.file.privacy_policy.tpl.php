<?php
/* Smarty version 4.2.1, created on 2023-03-26 14:36:31
  from '/home/hambrenc/public_html/app/views/templates/home/privacy_policy.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_6420586fa09795_00793844',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '85eaa7e6b9593a44c1cb13fe017570272fd6d7c2' => 
    array (
      0 => '/home/hambrenc/public_html/app/views/templates/home/privacy_policy.tpl',
      1 => 1679820752,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6420586fa09795_00793844 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1381806106420586fa09099_31565402', "body");
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "index.tpl");
}
/* {block "body"} */
class Block_1381806106420586fa09099_31565402 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_1381806106420586fa09099_31565402',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    
<?php
}
}
/* {/block "body"} */
}
